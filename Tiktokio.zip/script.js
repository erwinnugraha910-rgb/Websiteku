// ==== MENU NAVIGASI HP ====
const menuToggle = document.querySelector('.menu-toggle');
const navLinks = document.querySelector('.nav-links');

menuToggle.addEventListener('click', () => {
  navLinks.classList.toggle('active');
});

navLinks.querySelectorAll('a').forEach(link => {
  link.addEventListener('click', () => {
    navLinks.classList.remove('active');
  });
});

// ==== SCROLL HALUS ====
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
  anchor.addEventListener('click', function(e) {
    e.preventDefault();
    const target = document.querySelector(this.getAttribute('href'));
    if (target) {
      window.scrollTo({
        top: target.offsetTop - 80,
        behavior: 'smooth'
      });
    }
  });
});

// ==== FUNGSI TEMPEL DARI CLIPBOARD ====
const pasteBtn = document.getElementById('pasteBtn');
const videoUrl = document.getElementById('videoUrl');

pasteBtn.addEventListener('click', async () => {
  try {
    const text = await navigator.clipboard.readText();
    if (text) {
      videoUrl.value = text.trim();
      showModal('✅ Berhasil', 'Tautan berhasil ditempel!');
    }
  } catch (err) {
    videoUrl.focus();
    showModal('ℹ️ Info', 'Silakan tempel tautan secara manual di kolom input.');
  }
});

// ==== TOMBOL DOWNLOAD ====
const downloadBtn = document.getElementById('downloadBtn');
const resultBox = document.getElementById('resultBox');

downloadBtn.addEventListener('click', () => {
  const url = videoUrl.value.trim();
  
  if (!url) {
    showModal('⚠️ Tautan Kosong', 'Silakan tempel tautan video TikTok terlebih dahulu!');
    return;
  }
  
  if (!url.includes('tiktok.com') && !url.includes('vt.tiktok.com')) {
    showModal('❌ Tautan Tidak Valid', 'Silakan masukkan tautan dari TikTok! Contoh: https://vt.tiktok.com/xxxxx');
    return;
  }
  
  // Animasi loading
  downloadBtn.disabled = true;
  downloadBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Memproses...';
  
  // Simulasi proses pengambilan data
  setTimeout(() => {
    downloadBtn.disabled = false;
    downloadBtn.innerHTML = '<i class="fas fa-download"></i> Download';
    
    // Tampilkan hasil
    resultBox.classList.remove('hidden');
    
    // Scroll ke hasil
    resultBox.scrollIntoView({ behavior: 'smooth', block: 'center' });
    
    showModal('✅ Berhasil Diproses!', 'Pilih format unduhan di bawah ini.');
  }, 1500);
});

// ==== PILIHAN FORMAT DOWNLOAD ====
const downloadOptions = document.querySelectorAll('.download-option');
downloadOptions.forEach(option => {
  option.addEventListener('click', () => {
    const type = option.getAttribute('data-type');
    let title = '',
      desc = '';
    
    switch (type) {
      case 'nowatermark':
        title = '🎉 Mulai Mengunduh...';
        desc = 'Video TikTok tanpa watermark sedang diunduh! Kualitas HD siap disimpan.';
        break;
      case 'watermark':
        title = '🎉 Mulai Mengunduh...';
        desc = 'Video TikTok dengan watermark sedang diunduh! Resolusi asli.';
        break;
      case 'mp3':
        title = '🎵 Mulai Mengunduh MP3...';
        desc = 'Audio TikTok sedang dikonversi & diunduh! Siap untuk nada dering.';
        break;
    }
    
    showModal(title, desc);
  });
});

// ==== FAQ ACCORDION ====
const faqItems = document.querySelectorAll('.faq-item');
faqItems.forEach(item => {
  const question = item.querySelector('.faq-question');
  question.addEventListener('click', () => {
    // Tutup yang lain
    faqItems.forEach(faq => {
      if (faq !== item) faq.classList.remove('active');
    });
    // Buka/tutup yang diklik
    item.classList.toggle('active');
  });
});

// ==== FUNGSI MODAL ====
const modal = document.getElementById('modal');
const modalTitle = document.getElementById('modalTitle');
const modalText = document.getElementById('modalText');
const modalClose = document.getElementById('modalClose');
const modalIcon = document.getElementById('modalIcon');

function showModal(title, text) {
  modalTitle.textContent = title;
  modalText.textContent = text;
  modal.classList.add('show');
}

modalClose.addEventListener('click', () => {
  modal.classList.remove('show');
});

modal.addEventListener('click', (e) => {
  if (e.target === modal) modal.classList.remove('show');
});

// ==== ENTER UNTUK DOWNLOAD ====
videoUrl.addEventListener('keydown', (e) => {
  if (e.key === 'Enter') {
    downloadBtn.click();
  }
});